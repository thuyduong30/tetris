package model;

/**
Piece: I
 *  Orientation:  
 *        up       left      down      right       up again
 *       _____     _____     _____     _____        _____
 *     0|   * |  0|     |  0|  *  |  0|     | ->  0| *   |
 *     1|   * |  1| ****|  1|  *  |  1|**** | ->  1| *   |
 *     2|   * |  2|     |  2|  *  |  2|     | ->  2| *   |
 *     3|   * |  3|     |  3|  *  |  3|     | ->  3| *   |
 *     4|_____|  4|_____|  4|_____|  4|_____| ->  4|_____|
 *       01234     01234     01234   01234          01234
 *     
 *     Notice this means that as you keep rotating it 
 *     will automatically move left
 */

import java.util.ArrayList;
import java.util.Iterator;

public class I extends Tetromino {
	/**
	 * Constructor. You may want to modify
	 * 
	 * @param game used in the call to super constructor
	 */
	public I(Game game) {
		super(game, "I", Cell.CYAN);

		for (int i = 0; i < layout.length; i++) {
			layout[i] = new ArrayList<Coordinate>();
		}

		//up
		layout[0].add(new Coordinate(0, 0));
		layout[0].add(new Coordinate(0, 1));
		layout[0].add(new Coordinate(0, 2));
		layout[0].add(new Coordinate(0, 3));
	}

	/**
	 * rotates the piece counter-clockwise. See above orientation for reference on
	 * which tile to rotate around.
	 */
	@Override
	public boolean rotate() {

		if (orientation == 0) {
			ArrayList<Coordinate> store = new ArrayList<Coordinate>();
			Coordinate reference = locations.get(1);
			int counter = 0;

			for (int i = -2; i < 2; i++) {

				if (i == 0) {
					store.add(reference);
					continue;

				} else {
					Coordinate temp = reference.translate(i, 0);

					if (inBounds(temp) && game.getBoardCell(temp.col, temp.row) 
							== Cell.EMPTY) {
						store.add(reference.translate(i, 0));
						counter++;
					}
				}
			}

			if (counter == 3) {
				Iterator<Coordinate> iter = locations.iterator();
				while (iter.hasNext()) {
					Coordinate c = iter.next();
					game.setBoardCell(c.col, c.row, Cell.EMPTY);
				}

				locations = store;

				Iterator<Coordinate> iter2 = locations.iterator();
				while (iter2.hasNext()) {
					Coordinate c = iter2.next();
					game.setBoardCell(c.col, c.row, cell);
				}

				orientation = 1;
				return true;
			}

		} else {
			ArrayList<Coordinate> store = new ArrayList<Coordinate>();
			Coordinate reference = locations.get(1);
			int counter = 0;

			for (int i = -1; i < 3; i++) {
				if (i == 0) {
					store.add(reference);
					continue;

				} else {
					Coordinate temp = reference.translate(0, i);

					if (inBounds(temp) && game.getBoardCell(temp.col, temp.row) 
							== Cell.EMPTY) {
						store.add(reference.translate(0, i));
						counter++;
					}
				}
			}

			if (counter == 3) {
				Iterator<Coordinate> iter = locations.iterator();
				while (iter.hasNext()) {
					Coordinate c = iter.next();
					game.setBoardCell(c.col, c.row, Cell.EMPTY);
				}

				locations = store;

				Iterator<Coordinate> iter2 = locations.iterator();
				while (iter2.hasNext()) {
					Coordinate c = iter2.next();
					game.setBoardCell(c.col, c.row, cell);
				}

				orientation = 0;
				return true;
			}
		}
		return false;
	}
}
