/**
 *  DO NOT MODIFY THIS CLASS
 */
package model;

public enum Action {
	MOVEUP, MOVEDOWN, MOVELFT, MOVERIGHT, ROTATE, FALL, COLLAPSE;
}
