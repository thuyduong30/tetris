package model;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * 
 * Piece: Z Orientation: up left down right _____ _____ _____ _____ 0 | | 0| * |
 * 0| | 0| * | 1 | ** | 1| ** | 1| ** | 1| ** | 2 | ** | 2| * | 2| ** | 2| * | 3
 * |_____| 3|_____| 3|_____| 3|_____| 01234 01234 01234 01234
 */

public class Z extends Tetromino {
	/**
	 * Constructor. You may want to modify
	 * 
	 * @param game used in the call to super constructor
	 */
	public Z(Game game) {
		super(game, "Z", Cell.RED);

		for (int i = 0; i < layout.length; i++) {
			layout[i] = new ArrayList<Coordinate>();
		}

		//up and down
		layout[0].add(new Coordinate(0, 0));
		layout[0].add(new Coordinate(-1, 0));
		layout[0].add(new Coordinate(0, 1));
		layout[0].add(new Coordinate(1, 1));

		//left and right
		layout[1].add(new Coordinate(0, 0));
		layout[1].add(new Coordinate(0, 1));
		layout[1].add(new Coordinate(1, -1));
		layout[1].add(new Coordinate(1, 0));

	}

	/**
	 * rotates the piece counter-clockwise. See above orientation for reference on
	 * which tile to rotate around.
	 */
	@Override
	public boolean rotate() {

		if (orientation == 0) {
			ArrayList<Coordinate> updated = new ArrayList<Coordinate>();

			if (setOrigin(locations.get(0).translate(0, 0)) == true) {
				Iterator<Coordinate> iter = layout[1].iterator();
				while (iter.hasNext()) {
					Coordinate c = iter.next();
					Coordinate b = origin.translate(c.col, c.row);

					if (inBounds(b) && available(b)) {
						updated.add(b);
					}
				}
			}

			if (updated.size() == 4) {
				Iterator<Coordinate> iter2 = locations.iterator();
				while (iter2.hasNext()) {
					Coordinate c = iter2.next();
					game.setBoardCell(c.col, c.row, Cell.EMPTY);
				}

				locations = updated;

				Iterator<Coordinate> iter3 = locations.iterator();
				while (iter3.hasNext()) {
					Coordinate c = iter3.next();
					game.setBoardCell(c.col, c.row, cell);
				}

				orientation = 1;
				return true;
			}

		} else {
			ArrayList<Coordinate> updated = new ArrayList<Coordinate>();

			if (setOrigin(locations.get(0).translate(0, 0)) == true) {
				Iterator<Coordinate> iter = layout[0].iterator();
				while (iter.hasNext()) {
					Coordinate c = iter.next();
					Coordinate b = origin.translate(c.col, c.row);

					if (inBounds(b) && available(b)) {
						updated.add(b);
					}
				}
			}

			if (updated.size() == 4) {
				Iterator<Coordinate> iter2 = locations.iterator();
				while (iter2.hasNext()) {
					Coordinate c = iter2.next();
					game.setBoardCell(c.col, c.row, Cell.EMPTY);
				}

				locations = updated;

				Iterator<Coordinate> iter3 = locations.iterator();
				while (iter3.hasNext()) {
					Coordinate c = iter3.next();
					game.setBoardCell(c.col, c.row, cell);
				}

				orientation = 0;
				return true;
			}
		}
		return false;
	}
}
