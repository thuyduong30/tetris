package model;

/**
 * 
 *  Piece: J
 *  Orientation:  
 *        up       left      down      right
 *       _____     _____     _____     _____
 *     0|  *  |  0|     |  0|  ** |  0| *   |
 *     1|  *  |  1| *** |  1|  *  |  1| *** | 
 *     2| **  |  2|   * |  2|  *  |  2|     |
 *     3|_____|  3|_____|  3|_____|  3|_____|
 *       01234     01234     01234     01234
 */

import java.util.ArrayList;
import java.util.Iterator;

public class J extends Tetromino {

	public J(Game game) {
		/**
		 * Constructor. You may want to modify
		 * 
		 * @param game used in the call to super constructor
		 */
		super(game, "J", Cell.BLUE);

		for (int i = 0; i < layout.length; i++) {
			layout[i] = new ArrayList<Coordinate>();
		}

		// up
		layout[0].add(new Coordinate(0, 0));
		layout[0].add(new Coordinate(0, 1));
		layout[0].add(new Coordinate(0, 2));
		layout[0].add(new Coordinate(-1, 2));

		// left
		layout[3].add(new Coordinate(0, 0));
		layout[3].add(new Coordinate(1, 0));
		layout[3].add(new Coordinate(2, 0));
		layout[3].add(new Coordinate(2, 1));

		// down
		layout[2].add(new Coordinate(0, 0));
		layout[2].add(new Coordinate(0, -1));
		layout[2].add(new Coordinate(0, -2));
		layout[2].add(new Coordinate(1, -2));

		// right
		layout[1].add(new Coordinate(0, 0));
		layout[1].add(new Coordinate(-1, 0));
		layout[1].add(new Coordinate(-2, 0));
		layout[1].add(new Coordinate(-2, -1));
	}

	/**
	 * rotates the piece counter-clockwise. See above orientation for reference on
	 * which tile to rotate around.
	 */
	@Override
	public boolean rotate() {
		if (orientation == 0) {
			ArrayList<Coordinate> updated = new ArrayList<Coordinate>();

			if (setOrigin(locations.get(0).translate(-1, 1)) == true) {
				Iterator<Coordinate> iter = layout[3].iterator();
				while (iter.hasNext()) {
					Coordinate c = iter.next();
					Coordinate b = origin.translate(c.col, c.row);

					if (inBounds(b) && available(b)) {
						updated.add(b);
					}
				}
			}

			if (updated.size() == 4) {
				Iterator<Coordinate> iter2 = locations.iterator();
				while (iter2.hasNext()) {
					Coordinate c = iter2.next();
					game.setBoardCell(c.col, c.row, Cell.EMPTY);
				}

				locations = updated;

				Iterator<Coordinate> iter3 = locations.iterator();
				while (iter3.hasNext()) {
					Coordinate c = iter3.next();
					game.setBoardCell(c.col, c.row, cell);
				}

				orientation = 3;
				return true;
			}

		} else if (orientation == 3) {
			ArrayList<Coordinate> updated = new ArrayList<Coordinate>();

			if (setOrigin(locations.get(0).translate(1, 1)) == true) {
				Iterator<Coordinate> iter = layout[2].iterator();
				while (iter.hasNext()) {
					Coordinate c = iter.next();
					Coordinate b = origin.translate(c.col, c.row);

					if (inBounds(b) && available(b)) {
						updated.add(b);
					}
				}
			}

			if (updated.size() == 4) {
				Iterator<Coordinate> iter2 = locations.iterator();
				while (iter2.hasNext()) {
					Coordinate c = iter2.next();
					game.setBoardCell(c.col, c.row, Cell.EMPTY);
				}

				locations = updated;

				Iterator<Coordinate> iter3 = locations.iterator();
				while (iter3.hasNext()) {
					Coordinate c = iter3.next();
					game.setBoardCell(c.col, c.row, cell);
				}

				orientation = 2;
				return true;
			}

		} else if (orientation == 2) {
			ArrayList<Coordinate> updated = new ArrayList<Coordinate>();

			if (setOrigin(locations.get(0).translate(1, -1)) == true) {
				Iterator<Coordinate> iter = layout[1].iterator();
				while (iter.hasNext()) {
					Coordinate c = iter.next();
					Coordinate b = origin.translate(c.col, c.row);

					if (inBounds(b) && available(b)) {
						updated.add(b);
					}
				}
			}

			if (updated.size() == 4) {
				Iterator<Coordinate> iter2 = locations.iterator();
				while (iter2.hasNext()) {
					Coordinate c = iter2.next();
					game.setBoardCell(c.col, c.row, Cell.EMPTY);
				}

				locations = updated;

				Iterator<Coordinate> iter3 = locations.iterator();
				while (iter3.hasNext()) {
					Coordinate c = iter3.next();
					game.setBoardCell(c.col, c.row, cell);
				}

				orientation = 1;
				return true;
			}

		} else {
			ArrayList<Coordinate> updated = new ArrayList<Coordinate>();

			if (setOrigin(locations.get(0).translate(-1, -1)) == true) {
				Iterator<Coordinate> iter = layout[0].iterator();
				while (iter.hasNext()) {
					Coordinate c = iter.next();
					Coordinate b = origin.translate(c.col, c.row);

					if (inBounds(b) && available(b)) {
						updated.add(b);
					}
				}
			}

			if (updated.size() == 4) {

				Iterator<Coordinate> iter2 = locations.iterator();
				while (iter2.hasNext()) {
					Coordinate c = iter2.next();
					game.setBoardCell(c.col, c.row, Cell.EMPTY);
				}

				locations = updated;

				Iterator<Coordinate> iter3 = locations.iterator();
				while (iter3.hasNext()) {
					Coordinate c = iter3.next();
					game.setBoardCell(c.col, c.row, cell);
				}

				orientation = 0;
				return true;
			}
		}
		return false;
	}
}
