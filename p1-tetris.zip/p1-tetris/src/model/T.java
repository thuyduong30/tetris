package model;

import java.util.ArrayList;

/**
 * 
 *  Piece: T
 *  Orientation:  
 *        up       left      down      right
 *       _____     _____     _____     _____
 *     0|     |  0|  *  |  0|  *  |  0|  *  |
 *     1| *** |  1|  ** |  1| *** |  1| **  |
 *     2|  *  |  2|  *  |  2|     |  2|  *  |
 *     3|_____|  3|_____|  3|_____|  3|_____|
 *       01234     01234     01234     01234
 */
public class T extends Tetromino {
	public T(Game game) {
		/**
		 * Constructor. You may want to modify
		 * @param game used in the call to super constructor
		 */
		super(game, "T", Cell.PURPLE);

		for(int i = 0; i < layout.length; i++) {
			layout[i] = new ArrayList <Coordinate> ();
		}
		
		//up
		layout[0].add(new Coordinate(0,0));
		layout[0].add(new Coordinate(1,0));
		layout[0].add(new Coordinate(-1,0));
		layout[0].add(new Coordinate(0,1));
	}

	/**
	 * rotates the piece counter-clockwise. See above orientation
	 * for reference on which tile to rotate around. 
	 */
	@Override
	public boolean rotate() {

		if (orientation == 0) {
			Coordinate reference = locations.get(0).translate(-1, 0); //(0,1)
			Coordinate update = reference.translate(1, -1);

			if(inBounds(update) &&
					game.getBoardCell(update.col, update.row) == Cell.EMPTY) {
				
				game.setBoardCell(reference.col, reference.row, Cell.EMPTY);
				locations.remove(reference);
				locations.add(update);
				game.setBoardCell(update.col, update.row, cell);

				orientation = 1;
				return true;	
			} 

		} else if (orientation == 1) {
			Coordinate reference = locations.get(0).translate(0, 1); //(0,1)
			Coordinate update = reference.translate(-1, -1);

			if(inBounds(update) &&
					game.getBoardCell(update.col, update.row) == Cell.EMPTY) {
				
				game.setBoardCell(reference.col, reference.row, Cell.EMPTY);
				locations.remove(reference);
				locations.add(update);
				game.setBoardCell(update.col, update.row, cell);

				orientation = 2;

				return true;
			}

		} else if (orientation == 2) {
			Coordinate reference = locations.get(0).translate(1, 0); //(0,1)
			Coordinate update = reference.translate(-1, 1);

			if(inBounds(update) &&
					game.getBoardCell(update.col, update.row) == Cell.EMPTY) {
				
				game.setBoardCell(reference.col, reference.row, Cell.EMPTY);
				locations.remove(reference);
				locations.add(update);
				game.setBoardCell(update.col, update.row, cell);

				orientation = 3;
				return true;
			} 

		} else {	
			Coordinate reference = locations.get(0).translate(0, -1); //(0,1)
			Coordinate update = reference.translate(1, 1);

			if(inBounds(update) &&
					game.getBoardCell(update.col, update.row) == Cell.EMPTY) {
				
				game.setBoardCell(reference.col, reference.row, Cell.EMPTY);
				locations.remove(reference);
				locations.add(update);
				game.setBoardCell(update.col, update.row, cell);


				orientation = 0;
				return true;
			}
		}	
		return false;
	}
}
